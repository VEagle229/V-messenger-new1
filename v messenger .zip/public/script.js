const socket = io();  // Connect to socket.io server

document.getElementById('chat-form').addEventListener('submit', function(e) {
  e.preventDefault();

  const input = document.getElementById('message-input');
  const message = input.value.trim();

  if (message !== '') {
    socket.emit('chat message', message);  // Send message to server

    addMessage(`You: ${message}`);  // Apne screen par message show karo

    input.value = '';  // Input box clear karo
  }
});

// Dusre users se messages receive karo
socket.on('chat message', function(msg) {
  addMessage(`Friend: ${msg}`);
});

// Message display karne ka function
function addMessage(msg) {
  const chatMessages = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.textContent = msg;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;  // Scroll bottom karo
}